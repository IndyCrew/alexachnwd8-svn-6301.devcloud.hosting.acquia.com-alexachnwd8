This is an example module implementing a request subscriber for Amazon Echo
Alexa Skill. The module will respond to one Alexa intent and reply "Hello
Drupal" to any other intent.

If you ask Alexa, "ask <my app> help" Amazon will call AMAZON.HelpIntent and
this module will respond with:

>For any other intent routed to this module the module will just respond
"Hello Drupal"
